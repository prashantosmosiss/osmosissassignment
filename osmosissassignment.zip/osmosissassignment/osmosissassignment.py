noofseats=input("init ")
converted_noofseats=int(noofseats)
students=[]
BV=[]
AV=[]
BNV=[]
ANV=[]
NA=[]
n=converted_noofseats/4
while True:
    inp=input()
    if inp=="fin":
        break
    if inp.startswith("reg"):
        students.append(inp)
for v in students:
    v=v.split()
    if v[2]=='B' and v[3]=='V' and len(BV)<n:
        BV.append(v[1])
    elif v[2]=='A' and v[3]=='V' and len(AV)<n:
        AV.append(v[1])
    elif v[2]=='B' and v[3]=='NV' and len(BNV)<n:
        BNV.append(v[1])
    elif v[2]=='A' and v[3]=='NV' and len(ANV)<n:
        ANV.append(v[1])
    else:
        NA.append(v[1])
print("BV : ",BV)
print("AV : ",AV)
print("BNV : ",BNV)
print("ANV : ",ANV)
print("NA : ",NA)
